# Assembler

Primero es necesario descargar la libreria del curso mediante pip:

```pip install iic2343```