# main.py

from utils.parser import read_assembly
from utils.symbol_table import parse_symbols
from utils.converter import to_binary
from utils.utils import simulate_write_in_rom, write_in_rom


def main(code_file, mode, debug=False):
    # Leer archivo de código assembly
    instructions = read_assembly(f"./tests/{code_file}")

    # Parsear labels (etiquetas y variables)
    symbols, vars = parse_symbols(instructions, debug)

    code_instructions = []

    # Guardar las variables en code_instructions como MOV (dir), Lit
    for dir, lit in vars.items():
        # code_instructions.append(f"MOV A, {lit}")
        # code_instructions.append(f"MOV ({dir}), A")
        code_instructions.append(f"MOV ({dir}), {lit}")

    # Detectar sección de código
    in_code = False
    for instr in instructions:
        if instr.upper() == "CODE:":
            in_code = True
            continue
        if in_code:
            # Quitar labels de code_instructions
            if instr.endswith(':'):
                continue
            code_instructions.append(instr)

    # Convertir a binario
    print("\nAnalizando instrucciones...")
    binary_instructions = to_binary(code_instructions, symbols, debug)

    # Depuración: Mostrar instrucciones binarias junto con las originales
    print("\n========= Instrucciones binarias =========")

    for i, bin_instr in enumerate(binary_instructions):
        literal = bin_instr[:16]
        literal_to_int = int(literal, 2)
        opcode = bin_instr[16:]
        print(
            f"{i}: {literal} {opcode} <- [{literal_to_int}] {code_instructions[i]}")

    if mode == "simulate":
        simulate_write_in_rom(binary_instructions)
    elif mode == "write":
        write_in_rom(binary_instructions)
    else:
        print(f"Comando desconocido => {mode}")


if __name__ == "__main__":
    etapa = 0
    test = 0
    # test = 'indirecto'
    # test = 'punteros'
    code_file = f"e{etapa}_{test}.txt"
    # code_file = "example.txt"
    mode = "write"  # "write" o "simulate"
    main(code_file, mode, debug=True)
