import json

# Leer el archivo JSON original
with open("opcodes.json", "r") as file:
    instructions = json.load(file)

# Calcular el ancho máximo de las claves para alinear
max_key_length = max(len(key) for key in instructions.keys())

# Crear una lista para almacenar las líneas formateadas
formatted_lines = []

for key, value in instructions.items():
    # Generar cada línea con alineación adecuada afuera de las comillas
    line = f'"{key}":'.ljust(max_key_length + 4) + f' "{value}"'
    formatted_lines.append(line)

# Guardar el resultado en un archivo .txt sin coma en el último elemento
with open("opcodes.json", "w") as file:
    file.write("{\n")
    for i, line in enumerate(formatted_lines):
        if i < len(formatted_lines) - 1:
            file.write(f"  {line},\n")
        else:
            file.write(f"  {line}\n")  # Última línea sin coma
    file.write("}\n")

print("Opcodes alineados y guardados en 'opcodes_aligned.txt' sin coma en el último elemento")
