library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.NUMERIC_STD.ALL;

entity ControlUnit is
Port (
clock : in std_logic;
address : in std_logic_vector (19 downto 0); -- Entran 20 bits desde rom_dataout, 7 bits de opcode
czn_ALU_status : in std_logic_vector (2 downto 0); -- CZN
dataout : out std_logic_vector (10 downto 0)); -- Palabras (señales de control)
end ControlUnit;

architecture Behavioral of ControlUnit is

-- Señales

signal opcode : std_logic_vector (6 downto 0); -- Opcode a extraer

type memory_array is array (0 to ((2 \*\* 7) - 1) ) of std_logic_vector (10 downto 0);

signal memory : memory_array:= ( -- Arreglar
"10001100000", -- MOV A,B
"01110000000", -- MOV B,A
"10000100000", -- MOV A,Lit
"01000100000", -- MOV B,Lit
"10001000000", -- MOV A,(Dir)
"01001000000", -- MOV B,(Dir)
"00110000001", -- MOV (Dir),A
"00001100001", -- MOV (Dir),B
"10111100000", -- ADD A,B
"01111100000", -- ADD B,A
"10110100000", -- ADD A,Lit
"", -- ADD B,Lit
"10111000000", -- ADD A,(Dir)
"", -- ADD B,(Dir)
"00111100001", -- ADD (Dir)
"10111100100", -- SUB A,B
"01111100100", -- SUB B,A
"10110100100", -- SUB A,Lit
"", -- SUB B,Lit
"10111000100", -- SUB A,(Dir)
"", -- SUB B,(Dir)
"00111100101", -- SUB (Dir)
"10111100100", -- AND A,B
"01111100100", -- AND B,A
"10110100100", -- AND A,Lit
"", -- AND B,Lit
"10111000100", -- AND A,(Dir)
"", -- AND B,(Dir)
"00111100101", -- AND (Dir)
"10111100100", -- OR A,B
"01111100100", -- OR B,A
"10110100100", -- OR A,Lit
"", -- OR B,Lit
"10111000100", -- OR A,(Dir)
"", -- OR B,(Dir)
"00111100101", -- OR (Dir)
"10111100100", -- XOR A,B
"01111100100", -- XOR B,A
"10110100100", -- XOR A,Lit
"", -- XOR B,Lit
"10111000100", -- XOR A,(Dir)
"", -- XOR B,(Dir)
"00111100101", -- XOR (Dir)
"10110010100", -- NOT A
"01110010100", -- NOT B,A
"00110010101", -- NOT (Dir),A
"10110011000", -- SHL A
"01110011000", -- SHL B,A
"00110011001", -- SHL (Dir),A
"10110011100", -- SHR A
"01110011100", -- SHR B,A
"00110011101", -- SHR (Dir),A
"", -- INC A
"01011100000", -- INC B
"", -- INC (Dir)
"", -- DEC A
"00111100100", -- CMP A,B
"00110100100", -- CMP A,Lit
"", -- CMP A,(Dir)
"00000000010", -- JMP Ins
"00000000010", -- JEQ Ins
"00000000010", -- JNE Ins
"00000000010", -- JGT Ins
"00000000010", -- JGE Ins
"00000000010", -- JLT Ins
"00000000010", -- JLE Ins
"00000000010", -- JCR Ins
"00000000000" -- NOP 0

);

begin

process (clock)
begin
if rising_edge(clock) then
-- Extraer los 7 bits menos significativos de la
-- instrucción (opcode), es decir, los bits de la derecha.
opcode <= address(6 downto 0);

        <!-- JMP	Ins	1000000
        JEQ	Ins	1000001
        JNE	Ins	1000010
        JGT	Ins	1000011
        JGE	Ins	1000100
        JLT	Ins	1000101
        JLE	Ins	1000110
        JCR	Ins	1000111
         -->

        dataout <= memory(to_integer(unsigned(opcode)));
    end if;

end process;

end Behavioral;
