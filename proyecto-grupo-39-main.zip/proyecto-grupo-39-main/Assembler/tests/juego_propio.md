// Juego de calzar los números
// Solo se juega con máximo 5 switches y 5 botones
// Solo se puede presionar/subir un switch a la vez


// (0) => 16 bits para leds
// (1) => 16 bits para switches
// (2) => 16 bits para display
// (3) => 16 bits para botones (en realidad solo últimos 5 bits)
// (4) => 16 bits para segundos
// (5) => 16 bits para milisegundos
// (6) => 16 bits para microsegundos
// (7) => 16 bits para LCD (No aplica)

DATA:
btn1 0 // 8
btn2 0 // 9 
turno 0 // 10

CODE:

start:

// Asignamos turno
MOV A,1
MOV (turno),A

MOV A,(1) // Leer switches
CMP A,1000000000000000b // Verificar que último switch esté prendido
JEQ cuenta_regresiva // Si está prendido, iniciar juego
JMP start // Si no, entonces, esperar a que se encienda


setear_0:
MOV A,0
MOV (4),A
MOV (0),A
JMP fin

cuenta_regresiva:
MOV (2),A
MOV A,3
MOV (2),A         // Mostrar 3 en display
esperar_3:
MOV A,(4)         // Leer segundos
CMP A,1           // Esperar 1 segundo
JNE esperar_3     // Si no ha pasado, seguir esperando
MOV A,2
MOV (2),A         // Mostrar 2 en display
esperar_2:
MOV A,(4)         // Leer segundos
CMP A,2           // Esperar otro segundo
JNE esperar_2     // Si no ha pasado, seguir esperando
MOV A,1
MOV (2),A         // Mostrar 1 en display
esperar_1:
MOV A,(4)         // Leer segundos
CMP A,3           // Esperar otro segundo
JNE esperar_1     // Si no ha pasado, seguir esperando

encender_luces:
MOV A,0000000000111111b
MOV (0),A                   // Encender luces de inicio
MOV A,(turno)
CMP A,1
JEQ turno_1
JMP turno_2                 // Si no, saltar a turno_2

turno_1:
MOV A,1BBBh                 // Mostrar que juega el jugador 1
MOV (2),A                   // Poner en el display
MOV A,2
MOV (turno),2
// Seteo para iniciar cuenta regresiva otra vez
MOV A,0
MOV (4),A
MOV (0),A
JMP fin               // Volver al inicio

turno_2:
MOV A,2BBBh                 // Mostrar que juega el jugador 2
MOV (2),A                   // Poner en el display
JMP fin                // Volver al inicio

fin:
JMP fin