# basic_computer.py

from typing import List, Dict
from opcodes.opcodes import dict_opcodes
from tabulate import tabulate


class BasicComputer:
    def __init__(self):
        self.A = 0  # Registro A
        self.B = 0  # Registro B
        self.ROM: List[str] = []  # Almacena las instrucciones
        self.RAM: List[int] = [0] * 256  # Memoria de 256 direcciones
        self.PC = 0  # Contador de programa
        self.ZF = False  # Zero Flag para operaciones de comparación
        self.SF = False  # Sign Flag para operaciones de comparación
        self.CF = False  # Carry Flag para operaciones de comparación

        # Definición de los opcodes
        self.dict_opcodes: Dict[str, str] = dict_opcodes

        # Invertir el diccionario para mapear opcode a operación
        self.opcode_to_instr = {v: k for k, v in self.dict_opcodes.items()}

        # Lista para almacenar los logs
        self.logs: List[Dict[str, str]] = []

        # Diccionario para contar ejecuciones por PC y detectar bucles
        self.execution_counts: Dict[int, int] = {}

    def load_program(self, program: List[str]):
        """Carga un programa en ROM."""
        self.ROM = program

    def binary_to_int(self, binary_str: str) -> int:
        """Convierte una cadena binaria a entero."""
        return int(binary_str, 2)

    def int_to_hex(self, value: int) -> str:
        """Convierte un entero a una cadena hexadecimal de dos dígitos."""
        return f"{value:02X}"

    def execute_instruction(self, instruction: str):
        """Ejecuta una instrucción de 32 bits."""
        # Dividir la instrucción en literal y opcode
        literal_bits = instruction[:16]
        opcode_bits = instruction[16:]

        # Convertir literal y opcode a enteros
        literal = self.binary_to_int(literal_bits)
        opcode = opcode_bits

        # Identificar la operación
        operation = self.opcode_to_instr.get(opcode, "UNKNOWN")

        # Preparar el log antes de la ejecución
        log_entry = {
            "Operation": operation,
            "Details": "",
            "Result": ""
        }

        if operation == "UNKNOWN":
            log_entry["Result"] = "UNKNOWN OPCODE"
            # Capturar valores de A y B después de la ejecución (no hay cambio)
            log_entry["A"] = self.int_to_hex(self.A)
            log_entry["B"] = self.int_to_hex(self.B)
            self.logs.append(log_entry)
            return

        # Ejecutar la operación
        if operation.startswith("MOV"):
            self.handle_mov(operation, literal, log_entry)
        elif operation.startswith("ADD"):
            self.handle_add(operation, literal, log_entry)
        elif operation.startswith("SUB"):
            self.handle_sub(operation, literal, log_entry)
        elif operation.startswith("AND"):
            self.handle_and(operation, literal, log_entry)
        elif operation.startswith("OR"):
            self.handle_or(operation, literal, log_entry)
        elif operation.startswith("XOR"):
            self.handle_xor(operation, literal, log_entry)
        elif operation.startswith("NOT"):
            self.handle_not(operation, literal, log_entry)
        elif operation.startswith("SHL"):
            self.handle_shl(operation, literal, log_entry)
        elif operation.startswith("SHR"):
            self.handle_shr(operation, literal, log_entry)
        elif operation.startswith("INC"):
            self.handle_inc(operation, literal, log_entry)
        elif operation.startswith("DEC"):
            self.handle_dec(operation, literal, log_entry)
        elif operation.startswith("CMP"):
            self.handle_cmp(operation, literal, log_entry)
        elif operation.startswith("JMP") or operation.startswith("J"):
            self.handle_jumps(operation, literal, log_entry)
            # Capturar valores de A y B después de la ejecución
            log_entry["A"] = self.int_to_hex(self.A)
            log_entry["B"] = self.int_to_hex(self.B)
            self.logs.append(log_entry)
            return
        elif operation.startswith("PUSH") or operation.startswith("POP") or operation.startswith("CALL") or operation.startswith("RET"):
            self.handle_subroutines(operation, literal, log_entry)
        else:
            log_entry["Result"] = f"NOT IMPLEMENTED"

        # Capturar valores de A y B después de la ejecución
        log_entry["A"] = self.int_to_hex(self.A)
        log_entry["B"] = self.int_to_hex(self.B)

        # Agregar el log a la lista
        self.logs.append(log_entry)

    def handle_mov(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones MOV."""
        if operation == "MOV A, B":
            self.A = self.B
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "MOV B, A":
            self.B = self.A
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "MOV A, Lit":
            self.A = literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "MOV B, Lit":
            self.B = literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "MOV A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV (dir), A":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = self.A
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV (dir), B":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = self.B
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV (B), A":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = self.A
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV (B), Lit":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = literal
                log_entry["Details"] = f"(B) = {addr}, L = {literal}"
                log_entry["Result"] = f"RAM[{addr}] = {literal}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "MOV B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_add(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones ADD."""
        if operation == "ADD A, B":
            self.A = (self.A + self.B) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "ADD B, A":
            self.B = (self.B + self.A) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "ADD A, Lit":
            self.A = (self.A + literal) & 0xFFFF
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "ADD B, Lit":
            self.B = (self.B + literal) & 0xFFFF
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "ADD A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = (self.A + self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "ADD B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = (self.B + self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "ADD (dir)":
            # Supongo que esto suma el contenido de (dir) a A
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = (self.A + self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "ADD A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = (self.A + self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "ADD B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = (self.B + self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_sub(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones SUB."""
        if operation == "SUB A, B":
            self.A = (self.A - self.B) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "SUB B, A":
            self.B = (self.B - self.A) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "SUB A, Lit":
            self.A = (self.A - literal) & 0xFFFF
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "SUB B, Lit":
            self.B = (self.B - literal) & 0xFFFF
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "SUB A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = (self.A - self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SUB B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = (self.B - self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SUB (dir)":
            # Supongo que esto resta el contenido de (dir) a A
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = (self.A - self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SUB A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = (self.A - self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SUB B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = (self.B - self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_and(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones AND."""
        if operation == "AND A, B":
            self.A = self.A & self.B
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "AND B, A":
            self.B = self.B & self.A
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "AND A, Lit":
            self.A = self.A & literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "AND B, Lit":
            self.B = self.B & literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "AND A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A & self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "AND B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = self.B & self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "AND (dir)":
            # Supongo que esto AND con A
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A & self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "AND A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = self.A & self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "AND B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = self.B & self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_or(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones OR."""
        if operation == "OR A, B":
            self.A = self.A | self.B
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "OR B, A":
            self.B = self.B | self.A
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "OR A, Lit":
            self.A = self.A | literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "OR B, Lit":
            self.B = self.B | literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "OR A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A | self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "OR B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = self.B | self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "OR (dir)":
            # Supongo que esto OR con A
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A | self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "OR A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = self.A | self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "OR B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = self.B | self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_xor(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones XOR."""
        if operation == "XOR A, B":
            self.A = self.A ^ self.B
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "XOR B, A":
            self.B = self.B ^ self.A
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "XOR A, Lit":
            self.A = self.A ^ literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "XOR B, Lit":
            self.B = self.B ^ literal
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "XOR A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A ^ self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "XOR B, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.B = self.B ^ self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "XOR (dir)":
            # Supongo que esto XOR con A
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.A = self.A ^ self.RAM[addr]
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "XOR A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.A = self.A ^ self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"A = {self.A}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "XOR B, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.B = self.B ^ self.RAM[addr]
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"B = {self.B}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_not(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones NOT."""
        if operation == "NOT A":
            self.A = (~self.A) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "NOT B":
            self.B = (~self.B) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "NOT (dir), A":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (~self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "NOT (B), A":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (~self.RAM[addr]) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_shl(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones SHL (Shift Left)."""
        if operation == "SHL A":
            self.A = (self.A << 1) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "SHL B, A":
            self.B = (self.B << 1) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "SHL (dir), A":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] << 1) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SHL (B), A":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] << 1) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_shr(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones SHR (Shift Right)."""
        if operation == "SHR A":
            self.A = (self.A >> 1) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "SHR B, A":
            self.B = (self.B >> 1) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "SHR (dir), A":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] >> 1) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "SHR (B), A":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] >> 1) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_inc(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones INC (Incremento)."""
        if operation == "INC A":
            self.A = (self.A + 1) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "INC B":
            self.B = (self.B + 1) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        elif operation == "INC (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] + 1) & 0xFFFF
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "INC (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                self.RAM[addr] = (self.RAM[addr] + 1) & 0xFFFF
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"RAM[{addr}] = {self.RAM[addr]}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_dec(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones DEC (Decremento)."""
        if operation == "DEC A":
            self.A = (self.A - 1) & 0xFFFF
            log_entry["Result"] = f"A = {self.A}"
        elif operation == "DEC B":
            self.B = (self.B - 1) & 0xFFFF
            log_entry["Result"] = f"B = {self.B}"
        # Puedes agregar más casos si tienes DEC para otras direcciones

    def handle_cmp(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones CMP (Comparación)."""
        if operation == "CMP A, B":
            value_a = self.A
            value_b = self.B
            self.ZF = (self.A == self.B)
            self.SF = (self.A < self.B)
            self.CF = (self.A < self.B)
            log_entry["Result"] = f"{value_a} vs {value_b}"
        elif operation == "CMP A, Lit":
            value_a = self.A
            value_b = literal
            self.ZF = (self.A == literal)
            self.SF = (self.A < literal)
            self.CF = (self.A < literal)
            log_entry["Details"] = f"Lit = {literal}"
            log_entry["Result"] = f"{value_a} vs {value_b}"
        elif operation == "CMP A, (dir)":
            addr = literal
            if 0 <= addr < len(self.RAM):
                value_a = self.A
                value_b = self.RAM[addr]
                self.ZF = (self.A == self.RAM[addr])
                self.SF = (self.A < self.RAM[addr])
                self.CF = (self.A < self.RAM[addr])
                log_entry["Details"] = f"dir = {addr}"
                log_entry["Result"] = f"{value_a} vs {value_b}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."
        elif operation == "CMP A, (B)":
            addr = self.B
            if 0 <= addr < len(self.RAM):
                value_a = self.A
                value_b = self.RAM[addr]
                self.ZF = (self.A == self.RAM[addr])
                self.SF = (self.A < self.RAM[addr])
                self.CF = (self.A < self.RAM[addr])
                log_entry["Details"] = f"(B) = {addr}"
                log_entry["Result"] = f"{value_a} vs {value_b}"
            else:
                log_entry["Result"] = f"Error: Dirección de RAM inválida {addr}."

    def handle_jumps(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones de salto."""
        jump = False
        condition = ""
        if operation == "JMP dir":
            jump = True
            condition = "Uncondicional"
        elif operation == "JEQ dir" and self.ZF:
            jump = True
            condition = "ZF == True"
        elif operation == "JNE dir" and not self.ZF:
            jump = True
            condition = "ZF == False"
        elif operation == "JGT dir":
            # Salta si A > B: ZF == False y SF == False
            if not self.ZF and not self.SF:
                jump = True
                condition = "A > B"
        elif operation == "JGE dir":
            # Salta si A >= B: ZF == True o SF == False
            if self.ZF or not self.SF:
                jump = True
                condition = "A >= B"
        elif operation == "JLT dir":
            # Salta si A < B: SF == True
            if self.SF:
                jump = True
                condition = "A < B"
        elif operation == "JLE dir":
            # Salta si A <= B: ZF == True o SF == True
            if self.ZF or self.SF:
                jump = True
                condition = "A <= B"
        elif operation == "JCR dir":
            # Salta si hay acarreo: CF == True
            if self.CF:
                jump = True
                condition = "CF == True"

        if jump:
            target_pc = literal
            if 0 <= target_pc < len(self.ROM):
                # Obtener la operación del target
                target_instruction = self.ROM[target_pc]
                target_opcode_bits = target_instruction[16:]
                target_operation = self.opcode_to_instr.get(
                    target_opcode_bits, "UNKNOWN OPCODE")
                log_entry["Details"] = f"ROM[{target_pc}]"
                log_entry["Result"] = f" => {target_operation}"
                log_entry["Condition"] = condition  # Añadir condición al log
                self.PC = target_pc
            else:
                log_entry["Result"] = f"Error: Dirección de ROM inválida {target_pc}."
        else:
            log_entry["Result"] = "SKIP"

    def handle_subroutines(self, operation: str, literal: int, log_entry: Dict[str, str]):
        """Maneja las operaciones de subrutinas como PUSH, POP, CALL, RET."""
        # Aquí puedes implementar una pila para manejar las subrutinas
        # Por simplicidad, no se implementa en este ejemplo
        log_entry["Result"] = f"Subrutina {operation} no implementada."

    def run(self):
        """Ejecuta todas las instrucciones en ROM."""
        while self.PC < len(self.ROM):
            # Detectar bucles
            if self.PC in self.execution_counts:
                self.execution_counts[self.PC] += 1
                if self.execution_counts[self.PC] > 1:
                    print(
                        "Detección de bucle: La ejecución ha alcanzado el límite de iteraciones.")
                    break
            else:
                self.execution_counts[self.PC] = 1

            current_pc = self.PC  # Guardamos el valor actual de PC
            instruction = self.ROM[self.PC]
            self.execute_instruction(instruction)

            # Si la instrucción no modificó el PC (como un salto), lo incrementamos
            if self.PC == current_pc:
                self.PC += 1

    def print_logs(self):
        """Imprime los logs en formato de tabla."""
        headers = ["A", "B", "Operation", "Details", "Result"]
        table = []
        for log in self.logs:
            table.append([log["A"], log["B"], log["Operation"],
                         log["Details"], log["Result"]])
        print(tabulate(table, headers=headers, tablefmt="grid"))


def basic_computer(program):
    # Crear una instancia de la computadora
    computer = BasicComputer()
    # Cargar el programa en ROM
    computer.load_program(program)

    # Ejecutar el programa
    computer.run()

    # Mostrar los logs en forma de tabla
    print("\nEjecución del Programa:")
    computer.print_logs()


if __name__ == "__main__":
    program = [
        "00000000101010110000000000000011",  # MOV A, Lit (171)
        "00000000000000000000000000001000",  # MOV (0), A
        # CMP A, Lit (181) -- Suponiendo CMP opcode
        "00000000101110100000000000000001",
        "00000000000000000000000000000010",  # JEQ dir=2
        "00000000000000000000000000001010",  # JNE dir=10
        "00000000000000000000000000000000",  # NOP
        "00000000101010110000000000000011",  # MOV A, Lit (171)
        "00000000000000000000000000001000",  # MOV (0), A
        "00000000000000000000000000000000",  # NOP
        # JMP null (dir=0) para crear un loop
        "00000000000000000000000000000000"
    ]
    basic_computer(program)
