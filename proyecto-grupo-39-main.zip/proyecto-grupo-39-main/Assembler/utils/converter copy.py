# utils/converter.py

import re
from .utils import add_nop, format_binary, get_opcode, parse_literal
from .parser import normalizar_instruccion
from opcodes.opcodes import dict_opcodes


def to_binary(instructions, symbols):
    '''
    Convierte una lista de instrucciones en assembly a una lista de instrucciones en binario.
    '''
    binary_instructions = []
    instruction_address = 0  # Contador de instrucciones para manejar etiquetas

    # Recorre todas las instrucciones
    for instr in instructions:
        instr = normalizar_instruccion(instr)  # Normalizar la instrucción
        # Maneja etiquetas internas como ":" sin generar código
        if instr.endswith(':'):
            continue
        print(f"Procesando instrucción: {instr}")

        # Incrementar el contador de instrucciones
        instruction_address += 1

        # Verifica si la instrucción completa está en dict_opcodes (instrucciones sin operandos)
        if instr.upper() in dict_opcodes:
            opcode = get_opcode(instr.upper(), dict_opcodes, instr)
            if opcode:
                bin_instr = '0000000000000000' + opcode
                binary_instructions.append(bin_instr)
            continue

        matched = False  # Bandera para saber si la instrucción fue reconocida

        # Patrón para instrucciones tipo: INSTR REG, OPERANDO
        pattern_reg_oper = re.compile(
            r'^(MOV|ADD|SUB|AND|OR|XOR|CMP)\s+([AB]),\s*(.+)$', re.IGNORECASE)
        match = pattern_reg_oper.match(instr)
        if match:
            instr_type, reg, operand = match.groups()
            operand = operand.strip()
            try:
                if operand.upper() in ['A', 'B']:
                    # Registro a registro
                    instr_key = f"{instr_type.upper()} {reg.upper()},{operand.upper()}"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        bin_instr = '0000000000000000' + opcode
                        binary_instructions.append(bin_instr)
                else:
                    # Registro con literal o variable
                    literal = parse_literal(operand, symbols)
                    instr_key = f"{instr_type.upper()} {reg.upper()},Lit"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        literal_bin = format_binary(literal)
                        bin_instr = literal_bin + opcode
                        binary_instructions.append(bin_instr)
                matched = True
            except ValueError as e:
                print(e)
                add_nop(binary_instructions)
                matched = True

        # Patrón para instrucciones tipo: MOV (DIR), REG
        if not matched:
            pattern_mem_reg = re.compile(
                r'^(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR)\s*\(\s*(.+)\s*\)\s*,\s*([AB])$', re.IGNORECASE)
            match = pattern_mem_reg.match(instr)
            if match:
                instr_type, address, reg = match.groups()
                try:
                    address_value = parse_literal(address, symbols)
                    instr_key = f"{instr_type.upper()} (dir),{reg.upper()}"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        address_bin = format_binary(address_value)
                        bin_instr = address_bin + opcode
                        binary_instructions.append(bin_instr)
                    matched = True
                except ValueError as e:
                    print(e)
                    add_nop(binary_instructions)
                    matched = True

        # Patrón para instrucciones tipo: MOV REG, (DIR)
        if not matched:
            pattern_reg_mem = re.compile(
                r'^(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR)\s+([AB])\s*,\s*\(\s*(.+)\s*\)$', re.IGNORECASE)
            match = pattern_reg_mem.match(instr)
            if match:
                instr_type, reg, address = match.groups()
                try:
                    address_value = parse_literal(address, symbols)
                    instr_key = f"{instr_type.upper()} {reg.upper()},(dir)"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        address_bin = format_binary(address_value)
                        bin_instr = address_bin + opcode
                        binary_instructions.append(bin_instr)
                    matched = True
                except ValueError as e:
                    print(e)
                    add_nop(binary_instructions)
                    matched = True

        # Patrón para instrucciones tipo: MOV (DIR), LIT
        if not matched:
            pattern_mem_lit = re.compile(
                r'^(MOV)\s*\(\s*(.+)\s*\)\s*,\s*(.+)$', re.IGNORECASE)
            match = pattern_mem_lit.match(instr)
            if match:
                instr_type, address, literal_operand = match.groups()
                try:
                    address_value = parse_literal(address, symbols)
                    literal_value = parse_literal(literal_operand, symbols)
                    instr_key = f"{instr_type.upper()} (dir),Lit"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        address_bin = format_binary(address_value)
                        literal_bin = format_binary(literal_value)
                        bin_instr = address_bin + literal_bin + \
                            opcode  # Ajustar según el formato requerido
                        binary_instructions.append(bin_instr)
                    matched = True
                except ValueError as e:
                    print(e)
                    add_nop(binary_instructions)
                    matched = True

        # Patrón para instrucciones de salto: JMP LABEL
        if not matched:
            pattern_jump = re.compile(
                r'^(JMP|JEQ|JNE|JGT|JGE|JLT|JLE|JCR)\s+(.+)$', re.IGNORECASE)
            match = pattern_jump.match(instr)
            if match:
                instr_type, operand = match.groups()
                try:
                    address = symbols.get(operand, None)
                    if address is None:
                        address = parse_literal(operand, symbols)
                    instr_key = f"{instr_type.upper()} dir"
                    opcode = get_opcode(instr_key, dict_opcodes)
                    if opcode:
                        address_bin = format_binary(address)
                        bin_instr = address_bin + opcode
                        binary_instructions.append(bin_instr)
                    matched = True
                except ValueError as e:
                    print(e)
                    add_nop(binary_instructions)
                    matched = True

        # Si no se reconoció la instrucción
        if not matched:
            print(f"Instrucción no reconocida: {instr}")
            add_nop(binary_instructions)

    return binary_instructions
