import re
from .utils import add_nop, format_binary, get_opcode, parse_literal
from .parser import normalizar_instruccion
from opcodes.opcodes import dict_opcodes


def to_binary(instructions, symbols, debug):
    binary_instructions = []

    # Recorre todas las instrucciones
    for instr in instructions:

        # Si es un label: saltar
        if instr.endswith(':'):
            continue

        instr = normalizar_instruccion(instr)
        # print(f"Instrucción normalizada: {instr}")

        # Instrucciones sin literales ni direcciones
        if instr in dict_opcodes:
            # # if debug:
            # if "PUSH" in instr:
            #     print(f"\nProcesando instrucción: {instr} \n")

            opcode = dict_opcodes[instr]

            if "PUSH A" in instr:
                if debug:
                    print("CASO PUSH A => ", instr)
                instr_type = "PUSH"
                opcode = dict_opcodes.get(f"{instr_type} A")
                print(opcode)
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")
                bin_instr = '0000000000000000' + opcode
                binary_instructions.append(bin_instr)
                continue

            if "PUSH B" in instr:
                if debug:
                    print("CASO PUSH B =>", instr)
                instr_type = "PUSH"
                opcode = dict_opcodes.get(f"{instr_type} B")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")
                bin_instr = '0000000000000000' + opcode
                binary_instructions.append(bin_instr)
                continue

                # Caso particular de INC A
            if instr == "INC A":
                # if debug:
                #     print("Caso especial INC A")
                special_instructions = ["ADD A,1"]
                new_instructions = to_binary(
                    special_instructions, symbols, debug)
                binary_instructions.extend(new_instructions)
                continue

            # Caso particular de DEC A
            if instr == "DEC A":
                # if debug:
                #     print("Caso especial DEC A")
                special_instructions = ["SUB A,1"]
                new_instructions = to_binary(
                    special_instructions, symbols, debug)
                binary_instructions.extend(new_instructions)
                continue

            bin_instr = '0000000000000000' + opcode  # Rellenar con 16 ceros
            binary_instructions.append(bin_instr)
            continue

        # Instrucciones con acceso indirecto (por ejemplo, (B))
        ###################### * A, (B) ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP) A,\(B\)", instr):
            # if debug:
            # print("CASO A, (B)")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP)", instr).group(1)
            opcode = dict_opcodes.get(f"{instr_type} A, (B)")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * B, (B) ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP) B,\(B\)", instr):
            # if debug:
            #     print("CASO B, (B)")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP)", instr).group(1)
            opcode = dict_opcodes.get(f"{instr_type} B, (B)")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * (B), A ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR) \(B\),A", instr):
            # if debug:
            #     print("CASO (B), A")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR)", instr).group(1)
            opcode = dict_opcodes.get(f"{instr_type} (B), A")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * (B), Lit ######################
        elif re.match(r"(MOV) \(B\),(?!A\b|B\b)([^()]+)", instr):
            # if debug:
            #     print("CASO (B), Lit")
            instr_type = re.match(r"(MOV)", instr).group(1)
            literal = re.search(r'\(B\),(.+)', instr).group(1).strip()
            literal = parse_literal(literal, symbols)
            opcode = dict_opcodes.get(f"{instr_type} (B), Lit")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            literal_bin = format(int(literal), '016b')
            bin_instr = literal_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * A, Lit ######################
        # Excluye paréntesis y registros A o B
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP) A,(?!\(|A\b|B\b)[^()]+$", instr):
            # if debug:
            # print("CASO A, Lit =>", instr)
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP)", instr).group(1)
            # Captura solo el literal sin paréntesis
            literal = re.search(r'A,([^()]+)', instr).group(1).strip()
            literal = parse_literal(literal, symbols)
            opcode = dict_opcodes.get(f"{instr_type} A, Lit")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            literal_bin = format(int(literal), '016b')
            bin_instr = literal_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * B, Lit ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP) B,(?!\(|A\b|B\b)(.+)", instr):
            # if debug:
            #     print("CASO B, Lit")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP)", instr).group(1)
            literal = re.search(r'B,(.+)', instr).group(1).strip()
            literal = parse_literal(literal, symbols)
            opcode = dict_opcodes.get(f"{instr_type} B, Lit")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            literal_bin = format(int(literal), '016b')
            bin_instr = literal_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        # Instrucciones entre registros A y B
        ###################### * A, B ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP) A,B", instr):
            # if debug:
            # print("CASO A, B")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP)", instr).group(1)
            opcode = dict_opcodes.get(f"{instr_type} A, B")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * B, A ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|CMP|NOT|SHL|SHR) B,A", instr):
            # if debug:
            #     print("CASO B, A")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|CMP|NOT|SHL|SHR)", instr).group(1)
            opcode = dict_opcodes.get(f"{instr_type} B, A")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        # Instrucciones con direcciones
        ###################### * A, (dir) ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR|CMP) A,\([a-zA-Z0-9_-]+\)", instr):
            # if debug:
            #     print("CASO A, (dir)")
            #     print(f"Instrucción: {instr}")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR|CMP)", instr).group(1)
            address = re.search(r'\(([a-zA-Z0-9_-]+)\)', instr).group(1)
            if address in ["A", "B"]:
                opcode = dict_opcodes.get(f"{instr_type} A, ({address})")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(
                        f"Operación no reconocida para {instr_type} con ({address})")
                bin_instr = '0000000000000000' + opcode
            elif address.isdigit():
                address = parse_literal(address, symbols)
                # address = address * 2
                opcode = dict_opcodes.get(f"{instr_type} A, (dir)")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            else:
                address = parse_literal(address, symbols)
                opcode = dict_opcodes.get(f"{instr_type} A, (dir)")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        # Instrucciones con direcciones inversas (por ejemplo, MOV (dir), A)
        ###################### * (dir), A ######################
        elif re.match(r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR) \([a-zA-Z0-9_-]+\),A", instr):
            # if debug:
            #     print("CASO (dir), A")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR)", instr).group(1)
            address = re.search(r'\(([a-zA-Z0-9_-]+)\)', instr).group(1)
            if address in ["A", "B"]:
                opcode = dict_opcodes.get(f"{instr_type} ({address}), A")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(
                        f"Operación no reconocida para {instr_type} con ({address})")
                bin_instr = '0000000000000000' + opcode
            elif address.isdigit():
                address = parse_literal(address, symbols)
                # address = address * 2
                opcode = dict_opcodes.get(f"{instr_type} (dir), A")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            else:
                address = parse_literal(address, symbols)
                opcode = dict_opcodes.get(f"{instr_type} (dir), A")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * B, (dir) ######################
        elif re.match(r"^(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR|CMP) B,\([a-zA-Z0-9_-]+\)$", instr):
            # if debug:
            #     print("CASO B, (dir)")
            instr_type = re.match(
                r"(MOV|ADD|SUB|AND|OR|XOR|NOT|SHL|SHR|CMP)", instr).group(1)
            address = re.search(r'\(([a-zA-Z0-9_-]+)\)', instr).group(1)

            if address in ["A", "B"]:
                opcode = dict_opcodes.get(f"{instr_type} B, ({address})")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(
                        f"Operación no reconocida para {instr_type} con ({address})")
                bin_instr = '0000000000000000' + opcode
            else:
                if address.isdigit():
                    # Ajuste por el doble espacio en memoria
                    # address = parse_literal(address, symbols) * 2
                    pass
                else:
                    address = parse_literal(address, symbols)

                opcode = dict_opcodes.get(f"{instr_type} B, (dir)")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")

                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode

            binary_instructions.append(bin_instr)
            continue

        ###################### * (dir), B ######################
        elif re.match(r"^(MOV|ADD|SUB|AND|OR|XOR) \([a-zA-Z0-9_-]+\),B$", instr):
            # if debug:
            #     print("CASO (dir), B")
            instr_type = re.match(r"(MOV|ADD|SUB|AND|OR|XOR)", instr).group(1)
            address = re.search(r'\(([a-zA-Z0-9_-]+)\)', instr).group(1)
            if address in ["A", "B"]:
                opcode = dict_opcodes.get(f"{instr_type} ({address}), B")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(
                        f"Operación no reconocida para {instr_type} con ({address})")
                bin_instr = '0000000000000000' + opcode
            elif address.isdigit():
                address = parse_literal(address, symbols)
                # address = address * 2
                opcode = dict_opcodes.get(f"{instr_type} (dir), B")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            else:
                address = parse_literal(address, symbols)
                opcode = dict_opcodes.get(f"{instr_type} (dir), B")
                if opcode is None:
                    add_nop(binary_instructions)
                    raise ValueError(f"Operación no reconocida: {instr}")
                address_bin = format(int(address), '016b')
                bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        # Instrucciones con direcciones sin operandos adicionales
        ###################### * (dir) ######################
        elif re.match(r"(ADD|SUB|AND|OR|XOR|INC) \([a-zA-Z0-9_-]+\)", instr):
            # if debug:
            # print("CASO (dir)")
            instr_type = re.match(
                r"(ADD|SUB|AND|OR|XOR|INC)", instr).group(1)
            address = re.search(r'\(([a-zA-Z0-9_-]+)\)', instr).group(1)
            if address.isdigit():
                # address = str(int(address) * 2)
                pass
            address = parse_literal(address, symbols)
            opcode = dict_opcodes.get(f"{instr_type} (dir)")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            address_bin = format(int(address), '016b')
            bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        # Saltos (Jumps)
        ###################### * JMP dir ######################
        elif re.match(r"(JMP|JEQ|JNE|JGT|JGE|JLT|JLE|JCR) \(?[a-zA-Z0-9_-]+\)?", instr):
            # if debug:
            # print("CASO JMP dir")
            instr_type = re.match(
                r"(JMP|JEQ|JNE|JGT|JGE|JLT|JLE|JCR)", instr).group(1)
            address = instr.split()[1]
            address = address.strip("()")
            # Revisar si la dirección es un label
            if address in symbols:
                address_val = symbols[address]
            else:
                # Si no es un label, asumir que es un literal
                address_val = parse_literal(address, symbols)
                address_val = address_val
            opcode = dict_opcodes.get(f"{instr_type} dir")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            address_bin = format(int(address_val), '016b')
            bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        # Subrutinas
        ###################### * CALL dir ######################
        elif re.match(r"CALL \(?[a-zA-Z0-9_-]+\)?", instr):
            # if debug:
            #     print("CASO CALL dir")
            instr_type = "CALL"
            
            # Extraer dirección o label
            address = instr.split()[1]  # Tomar la segunda palabra
            address = address.strip("()")  # Remover paréntesis si existen

            # Revisar si la dirección es un label
            if address in symbols:
                address_val = symbols[address]
            else:
                # Si no es un label, asumir que es un literal
                address_val = parse_literal(address, symbols)
            
            # Obtener el opcode correspondiente
            opcode = dict_opcodes.get(f"{instr_type}")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            
            # Convertir dirección a binario y generar instrucción
            address_bin = format(int(address_val), '016b')  # Dirección en 16 bits
            bin_instr = address_bin + opcode
            binary_instructions.append(bin_instr)
            continue

        
        ###################### * PUSH A ######################
        elif re.match(r"PUSH A", instr):
            if debug:
                print("CASO PUSH A => ", instr)
            instr_type = "PUSH"
            opcode = dict_opcodes.get(f"{instr_type} A")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * PUSH B ######################
        elif re.match(r"PUSH B", instr):
            if debug:
                print("CASO PUSH B =>", instr)
            instr_type = "PUSH"
            opcode = dict_opcodes.get(f"{instr_type} B")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * POP A ######################
        # 2 Instrucciones distintas para ejecutarse:
        # "POP A1":        "00000000000001001010"
        # "POP A2":        "00000000000001001011"
        # Incrementa SP en una unidad y luego guarda el valor de Mem[SP] en A
        elif re.match(r"POP A", instr):
            if debug:
                print("CASO POP A => ", instr)
            instr_type = "POP"
            opcode = dict_opcodes.get(f"{instr_type} A1")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            opcode = dict_opcodes.get(f"{instr_type} A2")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        ###################### * POP B ######################
        # 2 Instrucciones distintas para ejecutarse:
        # "POP B1":        "00000000000001001100"
        # "POP B2":        "00000000000001001101"
        # Incrementa SP en una unidad y luego guarda el valor de Mem[SP] en B
        elif re.match(r"POP B", instr):
            if debug:
                print("CASO POP B => ", instr)
            instr_type = "POP"
            opcode = dict_opcodes.get(f"{instr_type} B1")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            opcode = dict_opcodes.get(f"{instr_type} B2")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        # RET con 2 instrucciones distintas
        ###################### * RET ######################
        # 2 Instrucciones distintas para ejecutarse:
        # "RET1":        "00000000000001001110"
        # "RET2":        "00000000000001001111"
        # Decrementa SP en una unidad y luego guarda el valor de Mem[SP] en PC
        elif re.match(r"RET", instr):
            if debug:
                print("CASO RET => ", instr)
            instr_type = "RET"
            opcode = dict_opcodes.get(f"{instr_type} 1")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            opcode = dict_opcodes.get(f"{instr_type} 2")
            if opcode is None:
                add_nop(binary_instructions)
                raise ValueError(f"Operación no reconocida: {instr}")
            bin_instr = '0000000000000000' + opcode
            binary_instructions.append(bin_instr)
            continue

        # Instrucción no reconocida
        else:
            print(f"Instrucción no reconocida: {instr}")
            add_nop(binary_instructions)  # NOP si no se reconoce
            continue

    return binary_instructions
