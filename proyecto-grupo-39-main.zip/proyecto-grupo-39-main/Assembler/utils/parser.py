# utils/parser.py

import re


def read_assembly(ruta):
    '''
    Lee un archivo de texto con instrucciones en assembly y retorna una lista con
    las instrucciones en el formato pedido.
    '''
    with open(ruta, 'r') as archivo:
        lineas = archivo.readlines()
    instrucciones = []
    for linea in lineas:
        # Eliminamos comentarios en línea
        linea = re.sub(r'//.*', '', linea)
        linea = linea.strip()
        if not linea:
            continue  # Ignoramos líneas en blanco
        instrucciones.append(linea)
    return instrucciones


def normalizar_instruccion(instr):
    '''
    Esta función recibe una instrucción en assembly y la normaliza
    para que sea más fácil de procesar. La normalización consiste en
    eliminar espacios innecesarios y reemplazarlos por un solo espacio.
    Además, elimina espacios dentro de los paréntesis.
    '''
    # Eliminar espacios después de '(' y antes de ')'
    instr = re.sub(r'\(\s*', '(', instr)
    instr = re.sub(r'\s*\)', ')', instr)
    # Reemplazar comas con una coma seguida de espacio
    instr = re.sub(r'\s*,\s*', ',', instr)
    # Reemplazar múltiples espacios/tabs por un solo espacio
    instr = re.sub(r'[ \t]+', ' ', instr).strip()
    return instr
