from tabulate import tabulate

# utils/symbol_table.py


def parse_symbols(instructions, debug):
    '''
    Esta función recibe una lista de instrucciones en assembly y retorna
    un diccionario con los símbolos definidos en el código y sus direcciones
    de memoria correspondientes. Los símbolos pueden ser etiquetas o variables.
    '''
    phys_symbols = {}
    virtual_symbols = {}
    vars = {}
    in_data_section = False
    in_code_section = False
    current_address = 0  # Dirección de memoria global

    # print("\n========= Asignación de memoria =========")
    print("\n==== INSTRUCCIONES EN MEMORIA ====")

    for instr in instructions:
        # print(f"Procesando línea: '{instr}' <- ({current_address})")

        # Verificar secciones DATA y CODE
        if instr.upper() == "DATA:":
            in_data_section = True
            in_code_section = False
            # print("Entrando en la sección DATA")
            continue

        elif instr.upper() == "CODE:":
            # current_address = current_address * 2  # DESCOMENTAR
            current_address = current_address
            in_data_section = False
            in_code_section = True
            # print("Entrando en la sección CODE")
            continue

        # Procesar sección DATA
        elif in_data_section:
            partes = instr.split()
            if not partes:
                continue  # Ignorar líneas vacías en DATA
            var_name = partes[0]
            # phys_symbols[var_name] = current_address * 2
            phys_symbols[var_name] = current_address + 8
            # Manejar inicialización de arreglos
            if len(partes) > 1:
                for valor in partes[1:]:
                    # print(f"{var_name} <- ({current_address})")
                    vars[current_address] = int(valor)
                    current_address += 1
            # else:
            #     current_address += 1
            continue

        # Procesar sección CODE
        elif in_code_section:
            if instr.endswith(':'):
                phys_symbols[instr[:-1]] = current_address
                continue

            print(f"{instr}: ({current_address})")
            # Cada instrucción en código ocupa una dirección
            # Excepto los labels
            current_address += 1
            continue

    if debug:
        print("\n==== VARIABLES Y LABELS ====")
        table = [[key, f"({value})"] for key, value in phys_symbols.items()]
        print(tabulate(table, headers=[
              "Physical Symbol", "Address"], tablefmt="grid"))
    return phys_symbols, vars
