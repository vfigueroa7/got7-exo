# utils/utils.py

from .basic_computer import basic_computer


def add_nop(binary_instructions):
    '''
    Agrega una instrucción NOP a la lista de instrucciones binarias.
    '''
    nop_binary = '000000000000000000000000000000000000'
    binary_instructions.append(nop_binary)


def format_binary(literal, bits=16):
    '''
    Formatea un valor entero a una cadena binaria con el número de bits especificado.
    '''
    return format(int(literal), f'0{bits}b')


def get_opcode(instr, dict_opcodes):
    '''
    Obtiene el opcode correspondiente a una clave del diccionario.
    Si no existe, retorna None y muestra un mensaje de error.
    '''
    opcode = dict_opcodes.get(instr)
    if not opcode:
        print(f"Instrucción {instr} no tiene opcode asociado.")
    return opcode


def parse_literal(literal, symbols):
    """
    Transforma el literal a un entero en distintos formatos: decimal (102d),
    binary (1010b), hexadecimal (AAh) o nombres de variables.
    """
    literal = literal.strip()

    # Manejo especial para los registros "A" y "B"
    if literal in ["A", "B"]:
        return literal  # O puedes devolver un valor específico para estos registros si es necesario

    # Caso literal con sufijo
    if literal.endswith(('d', 'b', 'h')):
        # Caso decimal
        if literal.endswith('d'):
            return int(literal[:-1], 10)
        # Caso binario
        elif literal.endswith('b'):
            return int(literal[:-1], 2)
        # Caso hexadecimal
        elif literal.endswith('h'):
            return int(literal[:-1], 16)
    # Caso decimal simple
    elif literal.isdigit():
        return int(literal, 10)
    # Caso variable (retorna dirección de memoria)
    elif literal in symbols:
        return symbols[literal]
    else:
        raise ValueError(f"Literal o símbolo no reconocido: {literal}")


def write_in_rom(binary_instructions, port_number=0):
    '''
    Función para escribir las instrucciones binarias en la ROM de la Basys3.
    '''
    from iic2343 import Basys3  # Importar aquí para evitar dependencias circulares
    instance = Basys3()
    # Cambia el puerto según sea necesario
    instance.begin(port_number=port_number)

    for i, instr in enumerate(binary_instructions):
        try:
            instr_to_int = int(instr, 2)
            # Convertir a 5 bytes (40 bits necesarios para Basys3)
            instr_to_bytes = instr_to_int.to_bytes(5, "big")
            instance.write(i, bytearray(instr_to_bytes))
        except Exception as e:
            print(
                f"Error al escribir la instrucción en ROM en la posición {i}: {e}")

    instance.end()


def simulate_write_in_rom(binary_instructions):
    '''
    Función para simular la escritura de las instrucciones binarias en la ROM.
    '''

    program = []

    print("\n========= Simulación de escritura en ROM =========")
    print("Escribiendo datos...")
    for i, instr in enumerate(binary_instructions):
        try:
            program.append(instr)
            instr_to_int = int(instr, 2)
            # Convertir a 5 bytes (40 bits necesarios para Basys3)
            instr_to_bytes = instr_to_int.to_bytes(5, "big")
        except Exception as e:
            print(
                f"Error al simular la escritura en ROM en la posición {i}: {e}")
    print("Datos escritos correctamente.\n")

    basic_computer(program)

    print("==================================================\n")
